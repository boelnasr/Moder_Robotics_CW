The prohect has been done following the wiki.
To run the program run "main.py".

The animation is carried on in Scene 6 using kinematics.csv (which can be found in 
results/best, results/overshoot or results/new_task).


I hope you find the code clean and understandable.
